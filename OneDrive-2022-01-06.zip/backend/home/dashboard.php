<!-- Header include - css,scripts and head -->
<?php include_once "../b_includes/header.php"; ?>
<?php include_once "../../init.php"; ?>
<?php include_once "../session_check.php" ?>



































<!-- Footer include - js and bottom scripts-->
<?php include_once "../b_includes/footer.php"; ?>

